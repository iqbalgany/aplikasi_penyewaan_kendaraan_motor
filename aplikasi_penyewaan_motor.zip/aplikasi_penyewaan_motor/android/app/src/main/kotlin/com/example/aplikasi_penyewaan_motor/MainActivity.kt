package com.example.aplikasi_penyewaan_motor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
